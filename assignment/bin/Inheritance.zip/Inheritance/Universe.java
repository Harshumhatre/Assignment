package Inheritance;

public class Universe {
	public void contains()
	{
		System.out.println("The universe contains all of the galaxies");
	}

}
