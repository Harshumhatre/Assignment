package Inheritance;

public class Galaxy extends SolarSystem{
	public void structure()
	{
		System.out.println("our milky way galaxy is one among billions of galaxies in our universe");
	}

}
