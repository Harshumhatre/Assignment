package Inheritance;

public class SolarSystem extends Universe {
	public void consist()
	{
	System.out.println("Solar system consist of Star,sun and everything bound to its gravity");
	}
}
