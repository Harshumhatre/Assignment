package Inheritance;

public class Earth extends Galaxy {
	public void life()
	{
		System.out.println("Earth is 3rd planet which support life");
	}
}
 