package Inheritance;

public class Moon extends Earth {
	public void article()
	{
		System.out.println("The moon is earth's only Natural Satellite");
	}
}
